# CONTEXT — lsuperagen.docs / AGENTS-SDK.SPACE
> สรุป context แชท Claude · Project: lsuperagent.docs · อัปเดต: 2026-09-17

---

## 1. เจ้าของโปรเจกต์

| Field | Value |
|---|---|
| ชื่อ | แบงค์ (THNB SMK) |
| อีเมล | thanabartb@gmail.com |
| GitHub | thanabartbb |
| Domain | **agents-sdk.space** (Cloudflare registrar, IANA 1910) |
| Nameservers | cosmin.ns.cloudflare.com, dara.ns.cloudflare.com |
| Domain cert | Cloudflare Certification Letter 9/8/2026 (verified) |

---

## 2. โปรเจกต์หลัก

### lsuperagen.docs
- **Repo:** github.com/thanabartbb/lsuperagent.docs
- **Stack:** Static HTML (ไม่มี framework) deploy บน Cloudflare Pages
- **Design system:** NEWGENRETIN v0.2
- **Status:** V11 · Public Beta

### LSUPERAGENT (ระบบใหญ่)
- **Repo:** github.com/thanabartb-ops/Lagensuper-Pro
- **Stack:** Next.js (App Router) + TypeScript + Tailwind + pnpm
- **Auth:** Supabase (primary) + Firebase (fallback) ผ่าน orchestrator
- **Supabase runtime:** ilzjtbfhoxirsuilwmor (lsuperagent-runtime, ap-northeast-1)
- **Release Gates:** R1–R3 PASS / R4–R5 PENDING / R6–R7 BLOCKED

---

## 3. ไฟล์ที่สร้างในแชทนี้ (ทั้งหมด 12 ไฟล์)

| ไฟล์ | หน้า / หน้าที่ |
|---|---|
| `index.html` | Homepage (baseline approved) |
| `login.html` | Login — split layout, OAuth 4 providers |
| `getting-started.html` | Docs / Getting Started |
| `guides.html` | Guides — filterable by level |
| `api.html` | API Reference — auth orchestrator, fallback logic |
| `tools.html` | Tools — 12 cards แบ่ง 3 หมวด |
| `examples.html` | **SDK Plug Tools** — 15 plugin cards แบ่ง 4 หมวด |
| `changelog.html` | Changelog — V11 release history |
| `workspace.html` | **Workspace / Protocol Studio** — 5 tabs |
| `wrangler.toml` | Cloudflare Pages config |
| `_redirects` | Clean URL mapping |
| `_headers` | Security headers + CSP |

---

## 4. Design System — NEWGENRETIN v0.2

### Material Ratio
- 85% Carbon Black (`#060606` → `#1d1f24`)
- 10% Gunmetal / Graphite
- 4% Ice Blue accent (`#63b3ff`) — เฉพาะ active/focus/indicator
- 1% High-contrast white

### Design Tokens หลัก
```css
--canvas: #060606
--surface: #0d0e10
--surf-el: #121316
--surf-in: #0a0a0b
--surf-act: rgba(99,179,255,.06)
--fg: #f5f7f9
--fg2: #a2a7b0
--fg3: #7c828c
--bd: #1c1e22
--bd2: #26292f
--bd3: #33373f
--acc: #63b3ff
--acc2: #8ec6ff
--accm: rgba(99,179,255,.14)
--focus: #63b3ff
--err: #ff6b6b
--ok: #57d39a
```

### Rules
- Chrome/metallic: เฉพาะ LS mark + login focal — ห้ามใช้เป็นพื้น card
- Radius: card ≤14px ห้ามเป็น pill
- Border: เส้นบางแทนเงา
- Blueprint grid: fixed overlay จาง ๆ ทุกหน้า

---

## 5. Workspace — SITE SDK POTOCALL Protocol

### 5 Tabs
| Tab | เนื้อหา |
|---|---|
| **Workspace** | Virtual Site dispenser grid (8 หัว + ATG), Release Gates R1–R7, stat counters |
| **Space SDK** | Packet Builder → CRC-16 Modbus live + Code Generator (TS/Python/C#) |
| **CLI** | 8 commands: init, ping, authorize, sniff, validate, deploy, atg, emergency-stop |
| **Sniffer** | Traffic table กรองตาม CMD, badge [OBS]/[VAL]/[INF] |
| **Spec Docs** | Frame Layout, Entity Table §1–§9, Command Dictionary, Troubleshooting |

### Protocol Spec
- **Document:** Site SDK POTOCALL Technical Blueprint v2.4-PRODUCTION
- **Frame:** STX(1) + LEN(2BE) + SEQ(1) + DEV_ID(1) + CMD(1) + PAYLOAD(N) + CRC16(2BE) + ETX(1)
- **CRC:** Polynomial 0xA001 / Init 0xFFFF (CRC-16 Modbus)
- **Key CMDs:** 0x10 PING, 0x20 AUTHORIZE, 0x30 FLOW, 0x40 DONE, 0x50 ATG, 0x60 E-STOP
- **DEV_ID:** 0x01–0x08 = Nozzles, 0x0A = ATG, 0xFF = Broadcast

### Boundary Statement (สำหรับ Compliance / OpenAI review)
- Packet Builder = reference implementation — ยังไม่ผ่าน certified hardware
- AUTO-SIM = simulation ทั้งหมด ไม่ใช่ hardware จริง
- Traffic Sniffer = static example ไม่ใช่ live capture
- R4–R7 = PENDING/BLOCKED — ห้ามใช้ใน production

---

## 6. Auth System

### Orchestrator Pattern
```typescript
import { signIn } from "@/lib/auth/orchestrator"
const outcome = await signIn({ method: "password", email, password })
// outcome.ok === true  → { user }
// outcome.ok === false → { reason }
```

### Fallback Triggers (Supabase → Firebase)
- `network` — เชื่อมต่อไม่ได้
- `provider_down` — provider ล่ม
- `config_missing` — ตั้งค่าไม่ครบ

### ไม่ fallback เมื่อ
- `invalid_credentials`, `email_taken`, `oauth_cancelled`

### OAuth Providers
- Google, GitHub, Microsoft (Azure), Apple

---

## 7. Deploy — Cloudflare Pages

### คำสั่ง
```bash
# ครั้งแรก
wrangler login
wrangler pages deploy . --project-name agents-sdk-space

# ครั้งถัดไป
wrangler pages deploy . --project-name agents-sdk-space
```

### Custom Domain
Cloudflare Dashboard → Workers & Pages → `agents-sdk-space` → Custom domains → `agents-sdk.space`
(DNS auto-config เพราะ nameserver ชี้มาที่ Cloudflare แล้ว)

### Routes
```
agents-sdk.space/              → index.html
agents-sdk.space/login         → login.html
agents-sdk.space/getting-started → getting-started.html
agents-sdk.space/guides        → guides.html
agents-sdk.space/api           → api.html
agents-sdk.space/tools         → tools.html
agents-sdk.space/examples      → examples.html (SDK Plug Tools)
agents-sdk.space/changelog     → changelog.html
agents-sdk.space/workspace     → workspace.html
```

---

## 8. งานที่ยังค้าง

- [ ] Deploy ขึ้น Cloudflare Pages จริง
- [ ] ผูก custom domain `agents-sdk.space`
- [ ] Wire Supabase + Firebase auth จริง (ตอนนี้ UI-only)
- [ ] ผ่าน Release Gate R4–R7
- [ ] Zapier MCP integration (token ใหม่ยังไม่ได้ setup)

---

## 9. Anti-patterns ที่ตกลงกันไว้

- ❌ ห้ามแสดง API key / secret ในหน้า UI
- ❌ ห้ามมี fake customer / testimonial / metric
- ❌ ห้ามทำหลายหน้าพร้อมกันโดยไม่ approve ทีละหน้า
- ❌ ห้าม chrome/metallic ลามทั้งจอ
- ❌ ห้าม card radius เป็น pill ขนาดใหญ่
- ✅ ทุกงานต้องมี evidence ก่อน mark เสร็จ
- ✅ สไตล์: ดิบ มีระบบ ไม่มีสายไฟเต้มพื้น
